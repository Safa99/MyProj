	var c_r=4,c_c=3,a_r=4,a_c=2,b_r=2,b_c=3;
	ChB=false;ChA=true; //radio button
	Swap=false; //Поменяны ли матрицы
	
	// var C,A,B = array[];
	
	
	var LeftPanel = document.getElementById('dLeft');//цвет левой панели
	var Er= document.getElementById('Error_bot');
	
	var ElRight = document.getElementById('dRight');
	s= ElRight.getElementsByTagName('input');
	
	var IdMatrA = document.getElementById('MatrA');
	var RowA = IdMatrA.getElementsByClassName('row');
	var ColsA = IdMatrA.getElementsByTagName('input');
	
	var IdMatrB = document.getElementById('MatrB');
	var RowB = IdMatrB.getElementsByClassName('row');
	var ColsB = IdMatrB.getElementsByTagName('input');
	
	var IdMatrC = document.getElementById('MatrC');
	var RowC = IdMatrB.getElementsByClassName('row');
	var ColsC = IdMatrC.getElementsByTagName('input');


	function addSetBackground(){
		var ElemsInput = document.getElementsByTagName('input');
		// 2  to  length-1
		
		
		
	}

	/*
	function calc(var MLeft, var MRight, var rML,var cML,var rMr,var cMR)
	{
		
	}
	*/
			// Умножение матриц
	function CalcMatr()
	{
		
		
		if (Swap)
		{
			if (b_c != a_r) 
			{
				//ошибка
				LeftPanel.style.background = '#f6c1c0';
				Er.style.visibility = 'visible';
				
				window.Er.innerHTML = 'Такие матрицы нельзя перемножить, так как количество столбцов матрицы B не равно количеству строк матрицы A.';
			}
			else
				{	//************ BEGIN
					if (b_c != a_r) 
				{
					//ошибка
					LeftPanel.style.background='#f6c1c0';
					Er.style.visibility = 'visible';
				}
				else
					{					
					//подсчет B * A

					
					
					var masA = new Array();
					var masB = new Array();
					var masRes = new Array();
					
					var k=i=j=0;
					for (i=0;i<a_r;i++)
					{
						masA[i] = new Array();
						for (j=0;j<a_c;j++)						
						{							
							masA[i][j]=ColsA[k].value;
							k++;
						}						
					}
					
					var k=0;
					for (i=0;i<b_r;i++)
					{
						masB[i] = new Array();
						for (j=0;j<b_c;j++)						
						{							
							masB[i][j]=ColsB[k].value;
							k++;
						}						
					}
					
					for (i=0;i<b_r;i++)
						masRes[i] = new Array();
					
					// УМНОЖЕНИЕ СТРОК НА СТОЛБЦЫ

					for (i= 0; i< a_c; i++)
						{ for (j = 0; j < b_r; j++)
							{ var t = 0;
								for (var k = 0; k < a_r; k++) t+= masB[j][k]*masA[k][i];
								masRes[j][i] = t;
							}
						}

						
					
					//--------------- Работа с матрицей С
// СДЕЛАТЬ ФОРМИРОВАНИЕ НОВОЙ МАТРИЦЫ "С" С УЧЕТОМ НОВЫХ РАЗМЕРОВ МАТРИЦ " А В "
						var buf = IdMatrC.getElementsByClassName('row'); 						
						for (var i=0;i<c_r;i++)
							IdMatrC.removeChild(buf[0])
						
						// Формирую матрицу С
						
						
						for (var i=0;i<b_r;i++)
						{
							var Clone= window.RowA[0].cloneNode(true);
							IdMatrC.appendChild(Clone);
							console.log(Clone);
							
						}
						
						
						c_r = b_r;
						c_c = a_c;
						
						k=0;
						for (i=0;i<c_r;i++)
							for (j=0;j<c_c;j++)						
							{
								ColsC[k].disabled=false;
							
								ColsC[k].value = masRes[i][j];
								ColsC[k].placeholder = 'c'+(i+1)+','+(j+1);
								
								ColsC[k].disabled=true;
								k++;
							}		
						ProverkaInput();
					//--------------
					}
					
					//************* END
				}
		}
		else //если не менялись
			{
				if (a_c != b_r) 
				{
					//ошибка
					LeftPanel.style.background='#f6c1c0';
					Er.style.visibility = 'visible';
					window.Er.innerHTML = 'Такие матрицы нельзя перемножить, так как количество столбцов матрицы A не равно количеству строк матрицы B.';
				}
				else
					{
					//подсчет A * B

						
				
					
					var masA = new Array();
					var masB = new Array();
					
					
					var k=i=j=0;
					for (i=0;i<a_r;i++)
					{
						masA[i] = new Array();
						for (j=0;j<a_c;j++)						
						{							
							masA[i][j]=ColsA[k].value;
							k++;
						}						
					}
					
					var k=0;
					for (i=0;i<b_r;i++)
					{
						masB[i] = new Array();
						for (j=0;j<b_c;j++)						
						{							
							masB[i][j]=ColsB[k].value;
							k++;
						}						
					}
					
					var masRes = new Array();
					for (i=0;i<a_r;i++)
						masRes[i] = new Array();
					
					// УМНОЖЕНИЕ СТРОК НА СТОЛБЦЫ

					for (i= 0; i< b_c; i++)
						{ for (j = 0; j < a_r; j++)
							{ var t = 0;
								for (var k = 0; k < b_r; k++) t+= masA[j][k]*masB[k][i];
								masRes[j][i] = t;
							}
						}
					//--------------- Работа с матрицей С
// СДЕЛАТЬ ФОРМИРОВАНИЕ НОВОЙ МАТРИЦЫ "С" С УЧЕТОМ НОВЫХ РАЗМЕРОВ МАТРИЦ " А В "
						//A * B
						//c_r = a_r;
						//c_c = b_c;
						
									//IdMatrC
		//RowC
		//ColsC
		//var buf = window.RowС;
		//console.log(buf);
		//console.log(window.RowС);
		//console.log(IdMatrC);
		//IdMatrС.removeChild(buf);
						
						
						var buf = window.IdMatrC.getElementsByClassName('row');
						
						for (var i=0;i<c_r;i++)
							window.IdMatrC.removeChild(buf[0])
						
						for (var i=0;i<a_r;i++)
						{
							var Clone= window.RowB[0].cloneNode(true);
							IdMatrC.appendChild(Clone);							
						}		
						
						c_r = a_r;
						c_c = b_c;	
						
						k=0;
						for (i=0;i<c_r;i++)
							for (j=0;j<c_c;j++)						
							{
								ColsC[k].disabled=false;
							
								ColsC[k].value = masRes[i][j];
								ColsC[k].placeholder = 'c'+(i+1)+','+(j+1);
								
								ColsC[k].disabled=true;
								k++;
							}		
						ProverkaInput();
					//--------------
					}
			}
				
		
	}
	
	
	
	
	function SelA(){
		/*var sel = */document.getElementById('CheckedA').checked=true;	
		/*sel.checked=true;*/
		ChA=true;
		ChB=false;	

	}
	
	function SelB(){
		/*var sel = */document.getElementById('CheckedB').checked=true;	
		/*sel.checked=true;*/
		ChA=false;
		ChB=true;
	}
	
	
		// Добавление строки
	function AddRow()
	{		
		if (ChA) 
		{			
			if (a_r+1==11) {
				alert("Матрица А не может иметь больше 10 строк!"); 
				return 0;
			}
//**********			
			a_r+=1;	
			var buf = RowA[a_r-2].cloneNode(true);
			//placeholder
			var col=1;
			var i;
			var bufInputs = buf.getElementsByTagName('input');
			
			//var val = bufInputs.value;
			//bufInputs.value = '';	
			for (i=0;i<bufInputs.length;i++)
			{
				bufInputs[i].placeholder = 'a'+a_r+','+col;
				bufInputs[i].value = '';
				col+=1;
				if (((i+1)%a_c)==0) col=1;
			}			
			window.IdMatrA.appendChild (buf);
			//bufInputs.value = val;	
			ProverkaInput();
			//alert('строка + '+' A');
		}
			else 
			{
				if (b_r+1==11) 
				{
				alert("Матрица B не может иметь больше 10 строк!"); 
				return 0;
				}

				b_r+=1;
				var buf = RowB[b_r-2].cloneNode(true);
				
				//placeholder
				var col=1;
				var i;
				var bufInputs = buf.getElementsByTagName('input');
				for (i=0;i<bufInputs.length;i++)
				{
					bufInputs[i].placeholder = 'b'+b_r+','+col;
					bufInputs[i].value = '';
					col+=1;
					if (((i+1)%b_c)==0) col=1;
				}

				window.IdMatrB.appendChild(buf);
				ProverkaInput();
				//alert('строка + '+' B');	
			}
	}
	
		// Добавление столбца
	function AddCol(){		
		if (ChA) 
		{
			if (a_c+1==11) 
				{
				alert("Матрица А не может иметь больше 10 столбцов!"); 
				return 0;
				}

			var last = ColsA.item(a_c-1);
				var val = last.value;
				last.value = '';
			for (var i=0;i<a_r;i++)
			{				
				 
				last.placeholder = 'a'+(i+1)+','+(a_c+1);	
				var CloneLast= last.cloneNode(true);				
				var bufRow = window.RowA.item(i);
				bufRow.appendChild(CloneLast);
			}
				last.value = val;
				last.placeholder = 'a'+1+','+a_c;
			a_c+=1;
			//alert('столбец + A')
			ProverkaInput();
		}
			else 
			{
				if (b_c+1==11) 
				{
				alert("Матрица В не может иметь больше 10 столбцов!"); 
				return 0;
				}

				var last = ColsB.item(b_c-1);	
				var val = last.value;
				last.value = '';			
				for (var i=0;i<b_r;i++)
			{				
				last.placeholder = 'b'+(i+1)+','+(b_c+1);
				var CloneLast= last.cloneNode(true);
				var bufRow = window.RowB.item(i);
				bufRow.appendChild(CloneLast);
			}
				last.value = val;
				last.placeholder = 'b'+1+','+b_c;	
				b_c+=1;
				//alert('столбец + B');
				ProverkaInput();
			}
	}
								///////УДАЛЕНИЕ СТРОКИ////////
		// Удаление строки
	function DelRow(){		
		if (ChA) 
		{
			if (a_r-1==1) 
				{
				alert("Матрица А не может иметь меньше 2-х строк!");
				return 0;
				}

			//alert('строка - '+' A')			
			a_r-=1;
			var buf = window.RowA.item(a_r);
			window.IdMatrA.removeChild(buf);
			ProverkaInput();			
		}
			else 
			{
				if (b_r-1==1) 
				{
				alert("Матрица B не может иметь меньше 2-х строк!");
				return 0;
				}

				b_r-=1;
				
				var buf = window.RowB.item(b_r); 
				window.IdMatrB.removeChild(buf);
				//alert('строка - '+' B');
			ProverkaInput();				
			}
	}
	
		// Удаление столбца
	function DelCol(){
		
		
		if (ChA)
		{
			if (a_c-1==1) 
				{
				alert("Матрица А не может иметь меньше 2-х столбцов!");
				return 0;
				}
			
			k=0;
			for (var i=1;i<=a_r;i++)
			{			
				var last = window.ColsA.item(a_c*i-1-k);	// Элемент							
				var bufRow = window.RowA.item(i-1); //Строка
				//var bufRow = window.ColsA;
				bufRow.removeChild(last);	
				k++;				
			}			
			a_c-=1;
			//alert('столбец - A')
			ProverkaInput();
		}
			else 
			{
				if (b_c-1==1) 
				{
				alert("Матрица B не может иметь меньше 2-х столбцов!");
				return 0;
				}

				k=0;
				for (var i=1;i<=b_r;i++)
				{			
					var last = window.ColsB.item(b_c*i-1-k);	// Элемент							
					var bufRow = window.RowB.item(i-1); //Строка
					//var bufRow = window.ColsA;
					bufRow.removeChild(last);	
					k++;				
				}				
				b_c-=1;
				//alert('столбец - B');
				ProverkaInput();
			}
	}
	
		// Очистить матрицы
	function ClearMatr()
	{
		var row=col=1;
		var i;
		var buf = document.getElementById('MatrA');

		for (i=0;i<ColsA.length;i++){
			ColsA[i].value = '';
			ColsA[i].placeholder = 'a'+row+','+col;
			col+=1;
			if (((i+1)%a_c)==0) {col=1;row+=1;}
			
		}
			 
		//console.log(ColsA[0].value);
		
		row=col=1;
		var buf = document.getElementById('MatrB');

		for (i=0;i<ColsB.length;i++){
			ColsB[i].value = '';
			ColsB[i].placeholder = 'b'+row+','+col;
			col+=1;
			if (((i+1)%b_c)==0) {col=1;row+=1;}
		}
			
		row=col=1;
		var buf = document.getElementById('MatrC');
		var inputsC = buf.getElementsByTagName('input');
		for (i=0;i<inputsC.length;i++){
			
			inputsC[i].disabled=false;
			
			inputsC[i].value = '';
			inputsC[i].placeholder = 'c'+row+','+col;
			
			inputsC[i].disabled=true;
			
			col+=1;
			if (((i+1)%c_c)==0) {col=1;row+=1;}
		}		
	}
	
	
	
		// Поменять матрицы местами
	function SwapMatr()
	{
			
		var matrA = window.IdMatrA;//document.getElementById('MatrA');
		var matrB = window.IdMatrB;//document.getElementById('MatrB');
		
		
		var bufA=matrA.cloneNode(true);
		var bufB=matrB.cloneNode(true);
		matrB.parentNode.insertBefore(bufA,matrB);
		matrA.parentNode.insertBefore(bufB,matrA);
		matrA.parentNode.removeChild(matrA);
		matrB.parentNode.removeChild(matrB);
	
	
		bufA=document.getElementById('A');
		bufB=document.getElementById('B');
		var buf = bufA.innerHTML;
		
		bufA.innerHTML = bufB.innerHTML;
		bufB.innerHTML = buf;
		
		window.IdMatrA = document.getElementById('MatrA');
		window.RowA = IdMatrA.getElementsByClassName('row');
		window.ColsA = IdMatrA.getElementsByTagName('input');
		
		window.IdMatrB = document.getElementById('MatrB');
		window.RowB = IdMatrB.getElementsByClassName('row');
		window.ColsB = IdMatrB.getElementsByTagName('input');
		

		if (Swap) {
			Swap=false;
			// A * B
			
			}
			else {
				Swap=true;
				// B * A
				
				}
		ProverkaInput();
	}
	
	
	
	

	function setBackground(){
		
		LeftPanel.style.background='#5199db';  // синий
	}	
	
	function set_stand()
	{
		Er.style.visibility = 'hidden';
		LeftPanel.style.background='#bcbcbc'; // серый
		
	}
	


function ProverkaInput()
{	

	for (var i=0;i<s.length-1;i++)
	{
		
		s[i].onkeyup = function()
			{	

					this.value = this.value.replace(/[^\d]/g,'');
					if (this.value>10) 
					{
						var j = this.value / 10;
						this.value = Math.floor(j); 
					}
			};
		
		s[i].onclick  = function()
		{
			Er.style.visibility = 'hidden';
			setBackground();
		}
		s[i].onblur = function(){set_stand();} 	
		
	}
}


window.onload = function()
{
		ProverkaInput();
}

